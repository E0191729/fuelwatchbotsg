package model;

public enum CommandResponseType {
    NONE, LOCATION, IMAGE, LINK
}
