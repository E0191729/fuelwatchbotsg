package model.json.publicbus;

import java.util.LinkedList;

import model.BusStop;

public class PublicBusStopContainer {
    public LinkedList<BusStop> value;
}
