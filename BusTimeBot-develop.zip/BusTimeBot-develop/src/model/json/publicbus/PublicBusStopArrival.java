package model.json.publicbus;

public class PublicBusStopArrival {
    public String ServiceNo;
    public String Operator;
    public String OriginCode;
    public String DestinationCode;
    public PublicBusArrival NextBus;
    public PublicBusArrival NextBus2;
    public PublicBusArrival NextBus3;
}
