package model.json.publicbus;

import java.util.LinkedList;

public class PublicBusStopArrivalContainer {
    public LinkedList<PublicBusStopArrival> Services;
}
