package model.json.publicbus;

public class PublicBusArrival {
    public String EstimatedArrival;
    public String Latitude;
    public String Longitude;
    public String VisitNumber;
    public String Load;
    public String Feature;
}
