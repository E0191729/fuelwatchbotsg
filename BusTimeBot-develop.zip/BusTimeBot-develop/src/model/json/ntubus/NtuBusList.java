package model.json.ntubus;

import java.util.ArrayList;

public class NtuBusList {
    public String external_id;
    public int id;
    public ArrayList<Route> routes;
}
