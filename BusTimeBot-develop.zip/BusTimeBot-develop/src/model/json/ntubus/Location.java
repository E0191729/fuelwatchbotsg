package model.json.ntubus;

public class Location {
    public double lat;
    public double lon;
}
