package model.json.ntubus;

public class Route {
    public int id;
    public String name;
    public String short_name;
}
