package model.json.ntubus;

import java.util.ArrayList;

public class Coordinate {
    public ArrayList<Location> center;
    public int id;
    public ArrayList<Node> nodes;
}
