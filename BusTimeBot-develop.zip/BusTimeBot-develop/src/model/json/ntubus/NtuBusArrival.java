package model.json.ntubus;

public class NtuBusArrival {
    public double forecast_seconds;
    public Route route;
    //ignore the rest
}
