package model.json.ntubus;

import java.util.ArrayList;

public class NtuBusArrivalContainer {
    public String external_id;
    public ArrayList<NtuBusArrival> forecast;
    public int id;
    public String name;
    //ignore the rest
}
