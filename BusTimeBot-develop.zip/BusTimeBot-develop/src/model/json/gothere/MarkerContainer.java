package model.json.gothere;

import java.util.ArrayList;

public class MarkerContainer {
    //For Business
    public ArrayList<Marker> markers;
}
