package model.json.nusbus;

public class NusBusStopContainer {
    public NusBusStops BusStopsResult;
}
