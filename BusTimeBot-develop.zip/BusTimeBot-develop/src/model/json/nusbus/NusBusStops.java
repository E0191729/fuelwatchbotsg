package model.json.nusbus;

import java.util.LinkedList;

public class NusBusStops {
    public LinkedList<NusBusStop> busstops;
}
