package model.json.nusbus;

import java.util.LinkedList;

public class NusBusArrivalSubContainer {
    public String caption;
    public String name;
    public LinkedList<NusBusArrival> shuttles;
}
