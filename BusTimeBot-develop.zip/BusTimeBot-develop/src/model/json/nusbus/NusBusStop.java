package model.json.nusbus;

public class NusBusStop {
    public String caption;
    public double latitude;
    public double longitude;
    public String name;
}
