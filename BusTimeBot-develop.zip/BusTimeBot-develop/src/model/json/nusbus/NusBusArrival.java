package model.json.nusbus;

public class NusBusArrival {
    public String arrivalTime;
    public String name;
    public String nextArrivalTime;
    public String nextPassengers;
    public String passengers;
}
