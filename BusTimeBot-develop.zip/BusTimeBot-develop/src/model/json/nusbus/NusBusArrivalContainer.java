package model.json.nusbus;

public class NusBusArrivalContainer {
    public NusBusArrivalSubContainer ShuttleServiceResult;
}
